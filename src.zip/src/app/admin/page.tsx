export default function AdminPage() {
  return <div>Admin Page</div>;
}
