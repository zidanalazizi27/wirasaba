// src/app/api/tenaga-kerja/route.ts
import { NextResponse } from 'next/server';
import mysql from 'mysql2/promise';

export async function GET() {
  try {
    const dbConnection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'wirasaba',
    });

    const [rows] = await dbConnection.execute<mysql.RowDataPacket[]>(
      'SELECT * FROM tenaga_kerja ORDER BY id_tenaga_kerja ASC'
    );
    const tenagaKerja = rows as mysql.RowDataPacket[];

    await dbConnection.end();

    return NextResponse.json({ 
      success: true, 
      count: tenagaKerja.length,
      data: tenagaKerja 
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
    console.error('Database error:', errorMessage);
    
    return NextResponse.json(
      { success: false, message: errorMessage },
      { status: 500 }
    );
  }
}