(()=>{var e={};e.id=6323,e.ids=[6323],e.modules={62849:e=>{function r(e){var r=Error("Cannot find module '"+e+"'");throw r.code="MODULE_NOT_FOUND",r}r.keys=()=>[],r.resolve=r,r.id=62849,e.exports=r},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{"use strict";e.exports=require("buffer")},84770:e=>{"use strict";e.exports=require("crypto")},17702:e=>{"use strict";e.exports=require("events")},98216:e=>{"use strict";e.exports=require("net")},35816:e=>{"use strict";e.exports=require("process")},76162:e=>{"use strict";e.exports=require("stream")},74026:e=>{"use strict";e.exports=require("string_decoder")},95346:e=>{"use strict";e.exports=require("timers")},82452:e=>{"use strict";e.exports=require("tls")},17360:e=>{"use strict";e.exports=require("url")},21764:e=>{"use strict";e.exports=require("util")},71568:e=>{"use strict";e.exports=require("zlib")},76093:(e,r,s)=>{"use strict";s.r(r),s.d(r,{originalPathname:()=>h,patchFetch:()=>x,requestAsyncStorage:()=>m,routeModule:()=>d,serverHooks:()=>v,staticGenerationAsyncStorage:()=>_});var a={};s.r(a),s.d(a,{GET:()=>l});var t=s(49303),i=s(88716),u=s(60670),n=s(87070),p=s(73785);let o={host:process.env.DB_HOST||"localhost",user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"",database:process.env.DB_NAME||"wirasaba"};async function c(){return await p.createConnection(o)}async function l(e){let r=e.nextUrl.searchParams.get("kip");if(!r)return n.NextResponse.json({success:!1,message:"Parameter KIP diperlukan"},{status:400});try{let e=await c(),s=`
      SELECT 
        r.id_riwayat,
        s.nama_survei,
        s.fungsi,
        s.periode,
        s.tahun,
        pcl.nama_pcl,
        r.selesai,
        r.ket_survei,
        p.nama_perusahaan,
        p.kip,
        p.id_perusahaan
      FROM riwayat_survei r
      JOIN survei s ON r.id_survei = s.id_survei
      JOIN perusahaan p ON r.id_perusahaan = p.id_perusahaan
      JOIN pcl ON r.id_pcl = pcl.id_pcl
      WHERE p.kip = ?
      ORDER BY s.tahun DESC, s.nama_survei ASC, p.nama_perusahaan ASC
    `,[a]=await e.execute(s,[r]);await e.end();let t=a.map(e=>({id_riwayat:e.id_riwayat,nama_survei:e.nama_survei,fungsi:e.fungsi||"",periode:e.periode||"",tahun:e.tahun,nama_pcl:e.nama_pcl,selesai:e.selesai,ket_survei:e.ket_survei||"",nama_perusahaan:e.nama_perusahaan,kip:e.kip,id_perusahaan:e.id_perusahaan})),i=t.length,u=t.filter(e=>"Iya"===e.selesai).length,p=t.filter(e=>"Tidak"===e.selesai).length,o=[...new Set(t.map(e=>`${e.nama_perusahaan} (ID: ${e.id_perusahaan})`))];return n.NextResponse.json({success:!0,message:`Berhasil mengambil ${i} riwayat survei untuk KIP ${r}`,data:t,summary:{kip:r,total_survei:i,selesai:u,belum_selesai:p,companies_count:o.length,companies:o}})}catch(e){return console.error("Database error:",e),n.NextResponse.json({success:!1,message:"Error saat mengambil data riwayat survei: "+e.message},{status:500})}}let d=new t.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/riwayat-survei/by-kip/route",pathname:"/api/riwayat-survei/by-kip",filename:"route",bundlePath:"app/api/riwayat-survei/by-kip/route"},resolvedPagePath:"D:\\Coding4Life\\Skripsi\\wirasaba\\src\\app\\api\\riwayat-survei\\by-kip\\route.ts",nextConfigOutput:"",userland:a}),{requestAsyncStorage:m,staticGenerationAsyncStorage:_,serverHooks:v}=d,h="/api/riwayat-survei/by-kip/route";function x(){return(0,u.patchFetch)({serverHooks:v,staticGenerationAsyncStorage:_})}}};var r=require("../../../../webpack-runtime.js");r.C(e);var s=e=>r(r.s=e),a=r.X(0,[8948,5972,3785],()=>s(76093));module.exports=a})();