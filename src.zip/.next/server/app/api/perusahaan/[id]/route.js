(()=>{var a={};a.id=4867,a.ids=[4867],a.modules={62849:a=>{function e(a){var e=Error("Cannot find module '"+a+"'");throw e.code="MODULE_NOT_FOUND",e}e.keys=()=>[],e.resolve=e,e.id=62849,a.exports=e},20399:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:a=>{"use strict";a.exports=require("buffer")},84770:a=>{"use strict";a.exports=require("crypto")},17702:a=>{"use strict";a.exports=require("events")},98216:a=>{"use strict";a.exports=require("net")},35816:a=>{"use strict";a.exports=require("process")},76162:a=>{"use strict";a.exports=require("stream")},74026:a=>{"use strict";a.exports=require("string_decoder")},95346:a=>{"use strict";a.exports=require("timers")},82452:a=>{"use strict";a.exports=require("tls")},17360:a=>{"use strict";a.exports=require("url")},21764:a=>{"use strict";a.exports=require("util")},71568:a=>{"use strict";a.exports=require("zlib")},25711:(a,e,r)=>{"use strict";r.r(e),r.d(e,{originalPathname:()=>m,patchFetch:()=>E,requestAsyncStorage:()=>_,routeModule:()=>d,serverHooks:()=>k,staticGenerationAsyncStorage:()=>h});var s={};r.r(s),r.d(s,{DELETE:()=>c,GET:()=>p,PUT:()=>l});var t=r(49303),n=r(88716),i=r(60670),u=r(87070),o=r(73785);async function p(a,{params:e}){let r=e.id;try{let a=await o.createConnection({host:process.env.DB_HOST,user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME}),[e]=await a.execute(`SELECT 
        p.id_perusahaan, p.kip, p.nama_perusahaan, 
        p.badan_usaha, bu.ket_bu AS badan_usaha_nama,
        p.alamat, 
        p.kec, k.nama_kec AS kec_nama,
        p.des, d.nama_des AS des_nama,
        p.kode_pos, p.skala,
        p.lok_perusahaan, lp.ket_lok AS lok_perusahaan_nama,
        p.nama_kawasan, p.lat, p.lon, p.jarak,
        p.produk, p.KBLI, p.telp_perusahaan, p.email_perusahaan, p.web_perusahaan,
        p.tkerja, tk.ket_tkerja AS tkerja_nama,
        p.investasi, i.ket_investasi AS investasi_nama,
        p.omset, o.ket_omset AS omset_nama,
        p.nama_narasumber, p.jbtn_narasumber, p.email_narasumber, p.telp_narasumber, p.catatan,
        p.pcl_utama
      FROM perusahaan p
      LEFT JOIN badan_usaha bu ON p.badan_usaha = bu.id_bu
      LEFT JOIN kecamatan k ON p.kec = k.kode_kec
      LEFT JOIN desa d ON p.des = d.kode_des
      LEFT JOIN lokasi_perusahaan lp ON p.lok_perusahaan = lp.id_lok
      LEFT JOIN tenaga_kerja tk ON p.tkerja = tk.id_tkerja
      LEFT JOIN investasi i ON p.investasi = i.id_investasi
      LEFT JOIN omset o ON p.omset = o.id_omset
      WHERE p.id_perusahaan = ?`,[r]);if(!e||0===e.length)return u.NextResponse.json({error:"Perusahaan tidak ditemukan"},{status:404});let[s]=await a.execute("SELECT thn_direktori FROM direktori WHERE id_perusahaan = ?",[r]);await a.end();let t=e[0],n=s.map(a=>a.thn_direktori);return u.NextResponse.json({...t,tahun_direktori:n})}catch(a){return console.error("Database error:",a),u.NextResponse.json({error:"Database error"},{status:500})}}async function l(a,{params:e}){let r=e.id;try{let e=await a.json();console.log("Update request for ID:",r),console.log("Update data:",e);let s=await o.createConnection({host:process.env.DB_HOST,user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME}),[t]=await s.execute(`UPDATE perusahaan 
       SET 
         kip = ?, 
         nama_perusahaan = ?, 
         badan_usaha = ?, 
         alamat = ?, 
         kec = ?, 
         des = ?, 
         kode_pos = ?, 
         skala = ?, 
         lok_perusahaan = ?, 
         nama_kawasan = ?, 
         lat = ?, 
         lon = ?, 
         jarak = ?, 
         produk = ?, 
         KBLI = ?, 
         telp_perusahaan = ?, 
         email_perusahaan = ?, 
         web_perusahaan = ?, 
         tkerja = ?, 
         investasi = ?, 
         omset = ?, 
         nama_narasumber = ?, 
         jbtn_narasumber = ?, 
         email_narasumber = ?, 
         telp_narasumber = ?, 
         pcl_utama = ?, 
         catatan = ?
       WHERE id_perusahaan = ?`,[e.kip||null,e.nama_perusahaan,e.badan_usaha,e.alamat,e.kec||null,e.des||null,e.kode_pos||null,e.skala,e.lok_perusahaan||null,e.nama_kawasan||null,e.lat||null,e.lon||null,e.jarak||null,e.produk||null,e.KBLI||null,e.telp_perusahaan||null,e.email_perusahaan||null,e.web_perusahaan||null,e.tkerja||null,e.investasi||null,e.omset||null,e.nama_narasumber||null,e.jbtn_narasumber||null,e.email_narasumber||null,e.telp_narasumber||null,e.pcl_utama||null,e.catatan||null,r]);if(e.tahun_direktori&&Array.isArray(e.tahun_direktori)&&(await s.execute("DELETE FROM direktori WHERE id_perusahaan = ?",[r]),e.tahun_direktori.length>0)){let a=e.tahun_direktori.map(a=>[r,a]);await s.query("INSERT INTO direktori (id_perusahaan, thn_direktori) VALUES ?",[a])}return console.log("Update result:",t),await s.end(),u.NextResponse.json({success:!0,message:"Data berhasil diperbarui"})}catch(a){return console.error("Database error:",a),u.NextResponse.json({success:!1,message:"Error saat memperbarui data: "+(a instanceof Error?a.message:"Unknown error")},{status:500})}}async function c(a,{params:e}){let r;let s=e.id;if(!s||isNaN(Number(s)))return u.NextResponse.json({success:!1,message:"ID perusahaan tidak valid"},{status:400});try{r=await o.createConnection({host:process.env.DB_HOST,user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME}),await r.beginTransaction();let[a]=await r.execute("SELECT nama_perusahaan FROM perusahaan WHERE id_perusahaan = ?",[s]);if(0===a.length)return await r.rollback(),u.NextResponse.json({success:!1,message:"Data perusahaan tidak ditemukan"},{status:404});let e=a[0].nama_perusahaan,[t]=await r.execute("SELECT COUNT(*) as count FROM riwayat_survei WHERE id_perusahaan = ?",[s]),n=t[0].count;n>0&&(console.log(`Menghapus ${n} riwayat survei untuk perusahaan ID ${s}`),await r.execute("DELETE FROM riwayat_survei WHERE id_perusahaan = ?",[s])),await r.execute("DELETE FROM direktori WHERE id_perusahaan = ?",[s]);let[i]=await r.execute("DELETE FROM perusahaan WHERE id_perusahaan = ?",[s]),p=i.affectedRows;if(0===p)return await r.rollback(),u.NextResponse.json({success:!1,message:"Gagal menghapus data perusahaan"},{status:500});return await r.commit(),console.log(`✅ Perusahaan "${e}" (ID: ${s}) berhasil dihapus beserta ${n} riwayat survei`),u.NextResponse.json({success:!0,message:`Data perusahaan "${e}" berhasil dihapus${n>0?` beserta ${n} riwayat survei`:""}`,deletedRelatedCount:n})}catch(e){if(console.error("❌ Database error saat menghapus perusahaan:",e),r)try{await r.rollback()}catch(a){console.error("Error during rollback:",a)}let a="Error saat menghapus data: ";return e instanceof Error&&"code"in e&&"ER_ROW_IS_REFERENCED_2"===e.code?a+="Data tidak dapat dihapus karena masih digunakan oleh data lain":e instanceof Error&&"code"in e&&"ER_LOCK_WAIT_TIMEOUT"===e.code?a+="Database sedang sibuk, silakan coba lagi":e instanceof Error&&"code"in e&&"ER_NO_REFERENCED_ROW_2"===e.code?a+="Data yang direferensikan tidak ditemukan":a+=(e instanceof Error?e.message:"Unknown database error")||"Unknown database error",u.NextResponse.json({success:!1,message:a},{status:500})}finally{if(r)try{await r.end()}catch(a){console.error("Error closing connection:",a)}}}let d=new t.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/perusahaan/[id]/route",pathname:"/api/perusahaan/[id]",filename:"route",bundlePath:"app/api/perusahaan/[id]/route"},resolvedPagePath:"D:\\Coding4Life\\Skripsi\\wirasaba\\src\\app\\api\\perusahaan\\[id]\\route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:_,staticGenerationAsyncStorage:h,serverHooks:k}=d,m="/api/perusahaan/[id]/route";function E(){return(0,i.patchFetch)({serverHooks:k,staticGenerationAsyncStorage:h})}}};var e=require("../../../../webpack-runtime.js");e.C(a);var r=a=>e(e.s=a),s=e.X(0,[8948,5972,3785],()=>r(25711));module.exports=s})();