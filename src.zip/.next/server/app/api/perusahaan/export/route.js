(()=>{var e={};e.id=7470,e.ids=[7470],e.modules={62849:e=>{function a(e){var a=Error("Cannot find module '"+e+"'");throw a.code="MODULE_NOT_FOUND",a}a.keys=()=>[],a.resolve=a,a.id=62849,e.exports=a},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{"use strict";e.exports=require("buffer")},84770:e=>{"use strict";e.exports=require("crypto")},17702:e=>{"use strict";e.exports=require("events")},98216:e=>{"use strict";e.exports=require("net")},35816:e=>{"use strict";e.exports=require("process")},76162:e=>{"use strict";e.exports=require("stream")},74026:e=>{"use strict";e.exports=require("string_decoder")},95346:e=>{"use strict";e.exports=require("timers")},82452:e=>{"use strict";e.exports=require("tls")},17360:e=>{"use strict";e.exports=require("url")},21764:e=>{"use strict";e.exports=require("util")},71568:e=>{"use strict";e.exports=require("zlib")},45970:(e,a,r)=>{"use strict";r.r(a),r.d(a,{originalPathname:()=>E,patchFetch:()=>x,requestAsyncStorage:()=>g,routeModule:()=>_,serverHooks:()=>w,staticGenerationAsyncStorage:()=>k});var t={};r.r(t),r.d(t,{GET:()=>m,dynamic:()=>l});var s=r(49303),n=r(88716),o=r(60670),i=r(87070),p=r(73785),u=r(55677);let l="force-dynamic",c={host:process.env.DB_HOST||"localhost",user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"",database:process.env.DB_NAME||"wirasaba"};async function h(){return await p.createConnection(c)}function d(e,a){let r,t;if(0===a)return{status:"kosong",status_text:"Kosong",completion_percentage:0};let s=Math.round(e/a*100);return s>=80?(r="tinggi",t="Tinggi"):s>=50?(r="sedang",t="Sedang"):(r="rendah",t="Rendah"),{status:r,status_text:t,completion_percentage:s}}async function m(e){let a=null;try{console.log("\uD83D\uDD04 Starting export process...");let r=e.nextUrl.searchParams,t=r.get("year"),s=r.get("search"),n=r.get("status"),o=r.get("pcl"),p=[],l=0;for(;r.get(`sort[${l}][column]`);){let e=r.get(`sort[${l}][column]`),a=r.get(`sort[${l}][direction]`)||"ascending";e&&p.push({column:e,direction:a}),l++}console.log("Export parameters:",{year:t,search:s,status:n,pcl:o,sortParams:p}),a=await h();let c=`
      SELECT 
        p.id_perusahaan, 
        p.kip, 
        p.nama_perusahaan, 
        p.badan_usaha, 
        p.alamat, 
        p.kec, k.nama_kec,
        p.des, d.nama_des,
        p.kode_pos, 
        p.skala,
        p.lok_perusahaan, 
        p.nama_kawasan, 
        p.lat, 
        p.lon, 
        p.jarak,
        p.produk, 
        p.KBLI, 
        p.telp_perusahaan, 
        p.email_perusahaan, 
        p.web_perusahaan,
        p.tkerja, 
        p.investasi, 
        p.omset,
        p.nama_narasumber, 
        p.jbtn_narasumber, 
        p.email_narasumber, 
        p.telp_narasumber, 
        p.pcl_utama, 
        p.catatan,
        GROUP_CONCAT(DISTINCT dir.thn_direktori ORDER BY dir.thn_direktori ASC) as tahun_direktori,
        -- ✅ FIXED: Total survei berdasarkan KIP (sama dengan tabel direktori)
        (SELECT COUNT(*) 
         FROM riwayat_survei rs 
         JOIN perusahaan p2 ON rs.id_perusahaan = p2.id_perusahaan 
         WHERE p2.kip = p.kip) AS total_survei,
        -- ✅ FIXED: Survei selesai berdasarkan KIP (sama dengan tabel direktori)
        (SELECT COUNT(*) 
         FROM riwayat_survei rs 
         JOIN perusahaan p2 ON rs.id_perusahaan = p2.id_perusahaan 
         WHERE p2.kip = p.kip AND rs.selesai = 'Iya') AS completed_survei
      FROM perusahaan p
      LEFT JOIN kecamatan k ON p.kec = k.kode_kec
      LEFT JOIN desa d ON p.des = d.kode_des
      LEFT JOIN direktori dir ON p.id_perusahaan = dir.id_perusahaan
    `,m=[],_=[];t&&"all"!==t&&(m.push("dir.thn_direktori = ?"),_.push(t)),s&&(m.push(`(
        p.kip LIKE ? OR 
        p.nama_perusahaan LIKE ? OR 
        p.alamat LIKE ? OR 
        p.pcl_utama LIKE ?
      )`),_.push(`%${s}%`,`%${s}%`,`%${s}%`,`%${s}%`)),o&&"all"!==o&&(m.push("p.pcl_utama = ?"),_.push(o));let g=c;if(m.length>0&&(g+=` WHERE ${m.join(" AND ")}`),g+=" GROUP BY p.id_perusahaan",p.length>0){let e=p.filter(e=>e.column&&e.direction).map(e=>{let a="ascending"===e.direction?"ASC":"DESC",r={kip:"p.kip",nama_perusahaan:"p.nama_perusahaan",alamat:"p.alamat",jarak:"CAST(REPLACE(REPLACE(p.jarak, ' km', ''), ',', '.') AS DECIMAL(10,2))",pcl_utama:"p.pcl_utama",kecamatan:"k.nama_kec",desa:"d.nama_des"}[e.column]||e.column;return`${r} ${a}`});e.length>0&&(g+=` ORDER BY ${e.join(", ")}`)}console.log("Executing query:",g),console.log("Query params:",_);let[k]=await a.execute(g,_);console.log(`Found ${k.length} businesses for export`);let w=k.map(e=>({...e,total_survei:e.total_survei||0,completed_survei:e.completed_survei||0}));console.log("Data processed successfully");let E=w;n&&"all"!==n&&(E=w.filter(e=>d(e.completed_survei,e.total_survei).status===n)),console.log("Filtered data count:",E.length),E.length>0&&(console.log("Sample data for verification:"),E.slice(0,3).forEach((e,a)=>{let r=d(e.completed_survei,e.total_survei);console.log(`Sample ${a+1}: ${e.nama_perusahaan} (KIP: ${e.kip}) - Total: ${e.total_survei}, Completed: ${e.completed_survei}, Percentage: ${r.completion_percentage}%, Status: ${r.status_text}`)}));let x=E.map((e,a)=>{let r=e.total_survei||0,t=e.completed_survei||0,s=d(t,r);return{No:a+1,KIP:e.kip||"","Nama Perusahaan":e.nama_perusahaan||"","Badan Usaha":e.badan_usaha||"",Alamat:e.alamat||"",Kecamatan:e.nama_kec||"",Desa:e.nama_des||"","Kode Pos":e.kode_pos||"",Skala:e.skala||"","Lokasi Perusahaan":e.lok_perusahaan||"","Nama Kawasan":e.nama_kawasan||"",Latitude:e.lat||"",Longitude:e.lon||"","Jarak (km)":e.jarak||"",Produk:e.produk||"",KBLI:e.KBLI||"","Telepon Perusahaan":e.telp_perusahaan||"","Email Perusahaan":e.email_perusahaan||"","Website Perusahaan":e.web_perusahaan||"","Tenaga Kerja":e.tkerja||"",Investasi:e.investasi||"",Omset:e.omset||"","Nama Narasumber":e.nama_narasumber||"","Jabatan Narasumber":e.jbtn_narasumber||"","Email Narasumber":e.email_narasumber||"","Telepon Narasumber":e.telp_narasumber||"","PCL Utama":e.pcl_utama||"",Catatan:e.catatan||"","Tahun Direktori":e.tahun_direktori||"","Total Survei":r,"Survei Selesai":t,"Persentase Penyelesaian (%)":s.completion_percentage,Status:s.status_text}});console.log("Export data formatted, creating Excel...");try{await a.end(),console.log("Database connection closed successfully")}catch(e){console.error("Error closing database connection:",e)}let b=u.utils.book_new(),v=u.utils.json_to_sheet(x);v["!cols"]=[{wch:5},{wch:15},{wch:30},{wch:10},{wch:40},{wch:15},{wch:15},{wch:10},{wch:10},{wch:10},{wch:20},{wch:15},{wch:15},{wch:12},{wch:30},{wch:10},{wch:15},{wch:25},{wch:25},{wch:10},{wch:10},{wch:10},{wch:20},{wch:20},{wch:25},{wch:15},{wch:15},{wch:30},{wch:15},{wch:12},{wch:12},{wch:20},{wch:12}],u.utils.book_append_sheet(b,v,"Data Direktori Perusahaan"),console.log("Excel workbook created, generating buffer...");let f=u.write(b,{type:"buffer",bookType:"xlsx",compression:!0});console.log("Excel buffer generated, size:",f.length);let O="direktori-perusahaan";return t&&"all"!==t&&(O+=`-tahun-${t}`),s&&(O+=`-search-${s.substring(0,10)}`),n&&"all"!==n&&(O+=`-status-${n}`),o&&"all"!==o&&(O+=`-pcl-${o.substring(0,10)}`),O+=".xlsx",console.log("Sending Excel file:",O),new i.NextResponse(f,{status:200,headers:{"Content-Type":"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","Content-Disposition":`attachment; filename="${O}"`,"Content-Length":f.length.toString()}})}catch(a){console.error("Detailed error in Excel export:",a);let e=a instanceof Error?a.message:"Unknown error occurred";return console.error("Error stack:",a instanceof Error?a.stack:void 0),i.NextResponse.json({success:!1,message:"Error generating Excel file: "+e,error:void 0},{status:500})}}let _=new s.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/perusahaan/export/route",pathname:"/api/perusahaan/export",filename:"route",bundlePath:"app/api/perusahaan/export/route"},resolvedPagePath:"D:\\Coding4Life\\Skripsi\\wirasaba\\src\\app\\api\\perusahaan\\export\\route.ts",nextConfigOutput:"",userland:t}),{requestAsyncStorage:g,staticGenerationAsyncStorage:k,serverHooks:w}=_,E="/api/perusahaan/export/route";function x(){return(0,o.patchFetch)({serverHooks:w,staticGenerationAsyncStorage:k})}}};var a=require("../../../../webpack-runtime.js");a.C(e);var r=e=>a(a.s=e),t=a.X(0,[8948,5972,3785,5677],()=>r(45970));module.exports=t})();