(()=>{var e={};e.id=8264,e.ids=[8264],e.modules={62849:e=>{function a(e){var a=Error("Cannot find module '"+e+"'");throw a.code="MODULE_NOT_FOUND",a}a.keys=()=>[],a.resolve=a,a.id=62849,e.exports=a},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{"use strict";e.exports=require("buffer")},84770:e=>{"use strict";e.exports=require("crypto")},17702:e=>{"use strict";e.exports=require("events")},98216:e=>{"use strict";e.exports=require("net")},35816:e=>{"use strict";e.exports=require("process")},76162:e=>{"use strict";e.exports=require("stream")},74026:e=>{"use strict";e.exports=require("string_decoder")},95346:e=>{"use strict";e.exports=require("timers")},82452:e=>{"use strict";e.exports=require("tls")},17360:e=>{"use strict";e.exports=require("url")},21764:e=>{"use strict";e.exports=require("util")},71568:e=>{"use strict";e.exports=require("zlib")},18704:(e,a,r)=>{"use strict";r.r(a),r.d(a,{originalPathname:()=>_,patchFetch:()=>k,requestAsyncStorage:()=>d,routeModule:()=>c,serverHooks:()=>h,staticGenerationAsyncStorage:()=>l});var s={};r.r(s),r.d(s,{GET:()=>i});var t=r(49303),p=r(88716),o=r(60670),n=r(87070),u=r(73785);async function i(){try{let e=await u.createConnection({host:process.env.DB_HOST||"localhost",user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"",database:process.env.DB_NAME||"wirasaba"}),[a]=await e.execute(`
      SELECT 
        p.id_perusahaan, 
        p.kip, 
        p.nama_perusahaan, 
        p.alamat, 
        p.kec, 
        p.des, 
        p.badan_usaha, 
        p.skala, 
        p.lok_perusahaan, 
        p.nama_kawasan, 
        p.lat, 
        p.lon, 
        p.produk, 
        p.KBLI, 
        p.telp_perusahaan, 
        p.email_perusahaan, 
        p.web_perusahaan,
        k.nama_kec,
        d.nama_des,
        bu.ket_bu AS badan_usaha_nama,
        lp.ket_lok AS lokasi_perusahaan_nama
      FROM 
        perusahaan p
      LEFT JOIN 
        kecamatan k ON p.kec = k.kode_kec
      LEFT JOIN 
        desa d ON p.des = d.kode_des
      LEFT JOIN 
        badan_usaha bu ON p.badan_usaha = bu.id_bu
      LEFT JOIN 
        lokasi_perusahaan lp ON p.lok_perusahaan = lp.id_lok
      WHERE 
        p.lat IS NOT NULL AND p.lon IS NOT NULL
    `);return console.log("Data perusahaan pertama:",a.length>0?a[0]:"Tidak ada data"),console.log(`Total data retrieved: ${a.length}`),await e.end(),n.NextResponse.json({success:!0,count:a.length,data:a})}catch(a){let e=a instanceof Error?a.message:"Unknown error occurred";return console.error("Database error:",e),n.NextResponse.json({success:!1,message:e},{status:500})}}let c=new t.AppRouteRouteModule({definition:{kind:p.x.APP_ROUTE,page:"/api/perusahaan/peta/route",pathname:"/api/perusahaan/peta",filename:"route",bundlePath:"app/api/perusahaan/peta/route"},resolvedPagePath:"D:\\Coding4Life\\Skripsi\\wirasaba\\src\\app\\api\\perusahaan\\peta\\route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:d,staticGenerationAsyncStorage:l,serverHooks:h}=c,_="/api/perusahaan/peta/route";function k(){return(0,o.patchFetch)({serverHooks:h,staticGenerationAsyncStorage:l})}}};var a=require("../../../../webpack-runtime.js");a.C(e);var r=e=>a(a.s=e),s=a.X(0,[8948,5972,3785],()=>r(18704));module.exports=s})();